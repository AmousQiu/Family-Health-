package com.example.a.l1;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ChildActivity extends BaseActivity implements View.OnClickListener{

    private static final String TAG = "ChildActivity.TAG";
    TextView titleTextView;
    public RelativeLayout health_layout;
    public RelativeLayout equipment_layout;
    public RelativeLayout news_layout;
    public RelativeLayout setting_layout;
    ViewPager mViewPager;
    ViewPagerFragmentAdapter mViewPagerFragmentAdapter;
    FragmentManager mFragmentManager;

    String[] titleName = new String[]{"父母身体监测", "设备参数设定", "代办事项", "设置"};
    List<Fragment> mFragmentList = new ArrayList<Fragment>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFragmentManager = getSupportFragmentManager();
        setContentView(R.layout.activity_child);

        initFragmetList();
        mViewPagerFragmentAdapter = new ViewPagerFragmentAdapter(mFragmentManager, mFragmentList);
        initView();
        initViewPager();



    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    public void initViewPager() {
        mViewPager.addOnPageChangeListener(new ViewPagetOnPagerChangedLisenter());
        mViewPager.setAdapter(mViewPagerFragmentAdapter);
        mViewPager.setCurrentItem(0);
        titleTextView.setText(titleName[0]);
        updateBottomLinearLayoutSelect(true, false, false,false);

    }

    public void initFragmetList() {
        Fragment health = new ChildHealthFragment();//chart
        Fragment equipment = new ChildEquipmentFragment();//friend
        Fragment news = new ChildNewsFragment();//find
        Fragment setting=new ChildSettingFragment();
        mFragmentList.add(health);
        mFragmentList.add(equipment);
        mFragmentList.add(news);
        mFragmentList.add(setting);

    }

    public void initView() {
        titleTextView = (TextView) findViewById(R.id.childViewTitle);
        mViewPager = (ViewPager) findViewById(R.id.childviewpager);
        health_layout = (RelativeLayout) findViewById(R.id.child_health_layout);
        health_layout.setOnClickListener(this);
        equipment_layout = (RelativeLayout) findViewById(R.id.child_equipment_layout);
        equipment_layout.setOnClickListener(this);
        news_layout = (RelativeLayout) findViewById(R.id.child_news_layout);
        news_layout.setOnClickListener(this);
        setting_layout=(RelativeLayout) findViewById(R.id.child_setting_layout);
        setting_layout.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.child_health_layout:
                mViewPager.setCurrentItem(0);
                updateBottomLinearLayoutSelect(true, false, false,false);
                break;
            case R.id.child_equipment_layout:
                mViewPager.setCurrentItem(1);
                updateBottomLinearLayoutSelect(false, true, false,false);
                break;
            case R.id.child_news_layout:
                mViewPager.setCurrentItem(2);
                updateBottomLinearLayoutSelect(false, false, true,false);
                break;
            case R.id.child_setting_layout:
                mViewPager.setCurrentItem(3);
                updateBottomLinearLayoutSelect(false, false, false,true);
                break;
            default:
                break;

        }

    }

    private void updateBottomLinearLayoutSelect(boolean f, boolean s, boolean t,boolean q) {
        health_layout.setSelected(f);
        equipment_layout.setSelected(s);
        news_layout.setSelected(t);
        setting_layout.setSelected(q);

    }

    class ViewPagetOnPagerChangedLisenter implements ViewPager.OnPageChangeListener {

        @Override


        public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            //            Log.d(TAG,"onPageScrooled");
        }

        @Override
        public void onPageSelected(int position) {
            Log.d(TAG, "onPageSelected");
            boolean[] state = new boolean[titleName.length];
            state[position] = true;
            titleTextView.setText(titleName[position]);
            updateBottomLinearLayoutSelect(state[0], state[1], state[2],state[3]);
        }

        @Override
        public void onPageScrollStateChanged(int state) {
            Log.d(TAG, "onPageScrollStateChanged");
        }
    }



}
