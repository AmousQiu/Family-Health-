package com.example.a.l1;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ParentHealthFragment extends Fragment {
    private TextView tv;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View healthLayout = inflater.inflate(R.layout.activity_parent_health, container, false);
        tv=(TextView) healthLayout.findViewById(R.id.parent_health);
        tv.setText("身体参数");
        return healthLayout;
    }

}
