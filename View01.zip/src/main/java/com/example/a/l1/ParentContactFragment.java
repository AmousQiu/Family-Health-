package com.example.a.l1;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ParentContactFragment extends Fragment {
    private TextView tv;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View contactLayout = inflater.inflate(R.layout.activity_parent_contact, container, false);
        tv=(TextView) contactLayout.findViewById(R.id.parent_contact);
        tv.setText("联系人");
        return contactLayout;
    }

}
