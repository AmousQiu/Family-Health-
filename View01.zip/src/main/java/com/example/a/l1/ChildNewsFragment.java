package com.example.a.l1;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ChildNewsFragment extends Fragment {
    private TextView tv;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View childNewsLayout = inflater.inflate(R.layout.activity_child_news, container, false);
        tv=(TextView) childNewsLayout.findViewById(R.id.child_news);
        tv.setText("待办事项");
        return childNewsLayout;
    }

}
