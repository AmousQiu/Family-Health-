package com.example.a.l1;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class ChildSettingFragment extends Fragment {
    private TextView tv;
    private Button exitbutton;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View childSettingLayout = inflater.inflate(R.layout.activity_child_setting, container, false);
        tv=(TextView) childSettingLayout.findViewById(R.id.child_setting);
        tv.setText("子女设置");
        exitbutton=(Button) childSettingLayout.findViewById(R.id.child_exit_button);
        exitbutton.setOnClickListener(new ButtonExitListener());
        return childSettingLayout;
    }

     private class ButtonExitListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            Intent intent=new Intent();
            intent.setClass(getActivity(), MainActivity.class);
            startActivity(intent);
            //finish();
        }
    }

}
