package com.example.a.l1;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class ChildHealthFragment extends Fragment {
    private TextView tv;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View childHealthLayout = inflater.inflate(R.layout.activity_child_health, container, false);
        tv=(TextView) childHealthLayout.findViewById(R.id.child_health);
        tv.setText("父母身体参数监测界面");
        return childHealthLayout;
    }

}
