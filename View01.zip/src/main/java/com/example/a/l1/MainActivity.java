package com.example.a.l1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class MainActivity extends BaseActivity {
    Button login_button;
    Button register_button;
    CheckBox login_parent;
    CheckBox login_child;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.initView();//获取控件

        register_button.setOnClickListener(new ButtonRegisterListener());
        login_button.setOnClickListener(new ButtonLoginListener());

    }

    private void initView(){
        login_button=(Button) findViewById(R.id.login_button);
        register_button=(Button) findViewById(R.id.register_button);
        login_parent=(CheckBox) findViewById(R.id.login_parent);
        login_child=(CheckBox) findViewById(R.id.login_child);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
    //点击的为返回键
        if (keyCode == event.KEYCODE_BACK) {
            exit();// 退出方法
        }
        return true;
    }

    private long time = 0;

    //退出方法
    private void exit() {
        if (System.currentTimeMillis() - time > 2000) {
            time = System.currentTimeMillis();
            showToast("再点击一次退出应用程序");
        } else {
            Intent intent = new Intent("drc.xxx.yyy.baseActivity");
            intent.putExtra("closeAll", 1);
            sendBroadcast(intent);//发送广播
        }
    }

    class ButtonRegisterListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            Intent intent=new Intent();
            intent.setClass(MainActivity.this,RegisterActivity.class);
            startActivity(intent);
            //finish();
        }
    }

    class ButtonLoginListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            if(login_parent.isChecked()&&!login_child.isChecked()) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, ParentActivity.class);
                startActivity(intent);
                //finish();
            }else if(!login_parent.isChecked()&&login_child.isChecked()){
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, ChildActivity.class);
                startActivity(intent);
                //finish();
            }
        }
    }

}
