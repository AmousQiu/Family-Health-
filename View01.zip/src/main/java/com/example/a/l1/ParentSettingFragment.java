package com.example.a.l1;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class ParentSettingFragment extends Fragment {
    private TextView tv;
    Button exitbutton;
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View settingLayout = inflater.inflate(R.layout.activity_parent_setting, container, false);
        tv=(TextView) settingLayout.findViewById(R.id.parent_setting);
        tv.setText("设置");
        exitbutton=(Button)settingLayout.findViewById(R.id.parent_exit_button);
        exitbutton.setOnClickListener(new ButtonExitListener());
        return settingLayout;
    }


    private class ButtonExitListener implements View.OnClickListener {

        @Override
        public void onClick(View v) {
            Intent intent=new Intent();
            intent.setClass(getActivity(), MainActivity.class);
            startActivity(intent);
            //finish();
        }
    }

}




